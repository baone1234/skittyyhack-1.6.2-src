// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.combat;

import net.minecraft.entity.player.EntityPlayer;
import me.earth.phobos.features.modules.Module;

public class SelfCrystal extends Module
{
    public SelfCrystal() {
        super("SelfCrystal", "Best module", Category.COMBAT, true, false, false);
    }
    
    @Override
    public void onTick() {
        if (AutoCrystal.getInstance().isEnabled()) {
            AutoCrystal.target = (EntityPlayer)SelfCrystal.mc.field_71439_g;
        }
    }
}
