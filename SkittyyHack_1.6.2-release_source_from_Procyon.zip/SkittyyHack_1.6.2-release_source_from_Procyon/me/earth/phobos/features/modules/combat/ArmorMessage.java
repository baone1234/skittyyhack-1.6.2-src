// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.combat;

import net.minecraft.init.Items;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import me.earth.phobos.features.command.Command;
import me.earth.phobos.util.DamageUtil;
import net.minecraft.item.ItemStack;
import me.earth.phobos.Phobos;
import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
import java.util.HashMap;
import me.earth.phobos.util.Timer;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Map;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class ArmorMessage extends Module
{
    private final Setting<Integer> armorThreshhold;
    private final Setting<Boolean> notifySelf;
    private final Setting<Boolean> notification;
    private final Map<EntityPlayer, Integer> entityArmorArraylist;
    private final Timer timer;
    
    public ArmorMessage() {
        super("ArmorMessage", "Message friends when their armor is low", Category.COMBAT, true, false, false);
        this.armorThreshhold = (Setting<Integer>)this.register(new Setting("Armor%", (T)20, (T)1, (T)100));
        this.notifySelf = (Setting<Boolean>)this.register(new Setting("NotifySelf", (T)true));
        this.notification = (Setting<Boolean>)this.register(new Setting("Notification", (T)true));
        this.entityArmorArraylist = new HashMap<EntityPlayer, Integer>();
        this.timer = new Timer();
    }
    
    @SubscribeEvent
    public void onUpdate(final UpdateWalkingPlayerEvent event) {
        for (final EntityPlayer player : ArmorMessage.mc.field_71441_e.field_73010_i) {
            if (!player.field_70128_L) {
                if (!Phobos.friendManager.isFriend(player.func_70005_c_())) {
                    continue;
                }
                for (final ItemStack stack : player.field_71071_by.field_70460_b) {
                    if (stack != ItemStack.field_190927_a) {
                        final int percent = DamageUtil.getRoundedDamage(stack);
                        if (percent <= this.armorThreshhold.getValue() && !this.entityArmorArraylist.containsKey(player)) {
                            if (player == ArmorMessage.mc.field_71439_g && this.notifySelf.getValue()) {
                                Command.sendMessage(player.func_70005_c_() + " watchout your " + this.getArmorPieceName(stack) + " low dura!", this.notification.getValue());
                            }
                            else {
                                ArmorMessage.mc.field_71439_g.func_71165_d("/msg " + player.func_70005_c_() + " " + player.func_70005_c_() + " watchout your " + this.getArmorPieceName(stack) + " low dura!");
                            }
                            this.entityArmorArraylist.put(player, player.field_71071_by.field_70460_b.indexOf((Object)stack));
                        }
                        if (!this.entityArmorArraylist.containsKey(player) || this.entityArmorArraylist.get(player) != player.field_71071_by.field_70460_b.indexOf((Object)stack) || percent <= this.armorThreshhold.getValue()) {
                            continue;
                        }
                        this.entityArmorArraylist.remove(player);
                    }
                }
                if (!this.entityArmorArraylist.containsKey(player) || player.field_71071_by.field_70460_b.get((int)this.entityArmorArraylist.get(player)) != ItemStack.field_190927_a) {
                    continue;
                }
                this.entityArmorArraylist.remove(player);
            }
        }
    }
    
    private String getArmorPieceName(final ItemStack stack) {
        if (stack.func_77973_b() == Items.field_151161_ac || stack.func_77973_b() == Items.field_151169_ag || stack.func_77973_b() == Items.field_151028_Y || stack.func_77973_b() == Items.field_151020_U || stack.func_77973_b() == Items.field_151024_Q) {
            return "helmet is";
        }
        if (stack.func_77973_b() == Items.field_151163_ad || stack.func_77973_b() == Items.field_151171_ah || stack.func_77973_b() == Items.field_151030_Z || stack.func_77973_b() == Items.field_151023_V || stack.func_77973_b() == Items.field_151027_R) {
            return "chestplate is";
        }
        if (stack.func_77973_b() == Items.field_151173_ae || stack.func_77973_b() == Items.field_151149_ai || stack.func_77973_b() == Items.field_151165_aa || stack.func_77973_b() == Items.field_151022_W || stack.func_77973_b() == Items.field_151026_S) {
            return "leggings are";
        }
        return "boots are";
    }
}
