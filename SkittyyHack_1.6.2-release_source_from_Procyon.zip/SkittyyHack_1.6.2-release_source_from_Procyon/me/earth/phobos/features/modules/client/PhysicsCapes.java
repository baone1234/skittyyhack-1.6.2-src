// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.client;

import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelBase;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.model.ModelRenderer;
import java.util.HashMap;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraft.util.ResourceLocation;
import me.earth.phobos.features.modules.Module;

public class PhysicsCapes extends Module
{
    public ModelPhyscisCapes cape;
    private final ResourceLocation capeTexture;
    
    public PhysicsCapes() {
        super("PhysicsCapes", "Capes with superior physics", Category.CLIENT, true, false, false);
        this.cape = new ModelPhyscisCapes();
        this.capeTexture = new ResourceLocation("textures/cape.png");
    }
    
    @SubscribeEvent
    public void onPlayerRender(final RenderPlayerEvent.Post event) {
        GlStateManager.func_179094_E();
        final float f11 = System.currentTimeMillis() / 1000.0f;
        final Map<ModelRenderer, Float> waveMap = new HashMap<ModelRenderer, Float>();
        float fuck = f11;
        for (final ModelRenderer renderer : this.cape.field_78092_r) {
            waveMap.put(renderer, (float)Math.sin(fuck / 0.5) * 4.0f);
            ++fuck;
        }
        final double rotate = this.interpolate(event.getEntityPlayer().field_70760_ar, event.getEntityPlayer().field_70761_aq, event.getPartialRenderTick());
        GlStateManager.func_179109_b(0.0f, 0.0f, 0.125f);
        final double d0 = event.getEntityPlayer().field_71091_bM + (event.getEntityPlayer().field_71094_bP - event.getEntityPlayer().field_71091_bM) * event.getPartialRenderTick() - (event.getEntityPlayer().field_70169_q + (event.getEntityPlayer().field_70165_t - event.getEntityPlayer().field_70169_q) * event.getPartialRenderTick());
        final double d2 = event.getEntityPlayer().field_71096_bN + (event.getEntityPlayer().field_71095_bQ - event.getEntityPlayer().field_71096_bN) * event.getPartialRenderTick() - (event.getEntityPlayer().field_70167_r + (event.getEntityPlayer().field_70163_u - event.getEntityPlayer().field_70167_r) * event.getPartialRenderTick());
        final double d3 = event.getEntityPlayer().field_71097_bO + (event.getEntityPlayer().field_71085_bR - event.getEntityPlayer().field_71097_bO) * event.getPartialRenderTick() - (event.getEntityPlayer().field_70166_s + (event.getEntityPlayer().field_70161_v - event.getEntityPlayer().field_70166_s) * event.getPartialRenderTick());
        final float f12 = event.getEntityPlayer().field_70760_ar + (event.getEntityPlayer().field_70761_aq - event.getEntityPlayer().field_70760_ar) * event.getPartialRenderTick();
        final double d4 = MathHelper.func_76126_a(f12 * 0.017453292f);
        final double d5 = -MathHelper.func_76134_b(f12 * 0.017453292f);
        float f13 = (float)d2 * 10.0f;
        f13 = MathHelper.func_76131_a(f13, -6.0f, 32.0f);
        float f14 = (float)(d0 * d4 + d3 * d5) * 100.0f;
        final float f15 = (float)(d0 * d5 - d3 * d4) * 100.0f;
        if (f14 < 0.0f) {
            f14 = 0.0f;
        }
        final float f16 = event.getEntityPlayer().field_71107_bF + (event.getEntityPlayer().field_71109_bG - event.getEntityPlayer().field_71107_bF) * event.getPartialRenderTick();
        f13 += MathHelper.func_76126_a((event.getEntityPlayer().field_70141_P + (event.getEntityPlayer().field_70140_Q - event.getEntityPlayer().field_70141_P) * event.getPartialRenderTick()) * 6.0f) * 32.0f * f16;
        if (event.getEntityPlayer().func_70093_af()) {
            f13 += 25.0f;
        }
        GL11.glRotated(-rotate, 0.0, 1.0, 0.0);
        GlStateManager.func_179114_b(180.0f, 1.0f, 0.0f, 0.0f);
        GL11.glTranslated(0.0, -(event.getEntityPlayer().field_70131_O - (event.getEntityPlayer().func_70093_af() ? 0.25 : 0.0) - 0.38), 0.0);
        GlStateManager.func_179114_b(6.0f + f14 / 2.0f + f13, 1.0f, 0.0f, 0.0f);
        GlStateManager.func_179114_b(f15 / 2.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.func_179114_b(-f15 / 2.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.func_179114_b(180.0f, 0.0f, 1.0f, 0.0f);
        if (PhysicsCapes.mc.field_71439_g.field_191988_bg != 0.0f || PhysicsCapes.mc.field_71439_g.field_70702_br != 0.0f) {
            for (final ModelRenderer renderer2 : this.cape.field_78092_r) {
                renderer2.field_78795_f = waveMap.get(renderer2);
            }
        }
        else {
            for (final ModelRenderer renderer2 : this.cape.field_78092_r) {
                renderer2.field_78795_f = 0.0f;
            }
        }
        Minecraft.func_71410_x().func_110434_K().func_110577_a(this.capeTexture);
        this.cape.func_78088_a(event.getEntity(), 0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
        Minecraft.func_71410_x().func_110434_K().func_147645_c(this.capeTexture);
        GlStateManager.func_179121_F();
    }
    
    public float interpolate(final float yaw1, final float yaw2, final float percent) {
        float rotation = (yaw1 + (yaw2 - yaw1) * percent) % 360.0f;
        if (rotation < 0.0f) {
            rotation += 360.0f;
        }
        return rotation;
    }
    
    public class ModelPhyscisCapes extends ModelBase
    {
        public ModelRenderer shape1;
        public ModelRenderer shape2;
        public ModelRenderer shape3;
        public ModelRenderer shape4;
        public ModelRenderer shape5;
        public ModelRenderer shape6;
        public ModelRenderer shape7;
        public ModelRenderer shape8;
        public ModelRenderer shape9;
        public ModelRenderer shape10;
        public ModelRenderer shape11;
        public ModelRenderer shape12;
        public ModelRenderer shape13;
        public ModelRenderer shape14;
        public ModelRenderer shape15;
        public ModelRenderer shape16;
        
        public ModelPhyscisCapes() {
            this.field_78090_t = 64;
            this.field_78089_u = 32;
            (this.shape9 = new ModelRenderer((ModelBase)this, 0, 8)).func_78793_a(-5.0f, 8.0f, -1.0f);
            this.shape9.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape15 = new ModelRenderer((ModelBase)this, 0, 14)).func_78793_a(-5.0f, 14.0f, -1.0f);
            this.shape15.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape3 = new ModelRenderer((ModelBase)this, 0, 2)).func_78793_a(-5.0f, 2.0f, -1.0f);
            this.shape3.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape7 = new ModelRenderer((ModelBase)this, 0, 6)).func_78793_a(-5.0f, 6.0f, -1.0f);
            this.shape7.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape1 = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-5.0f, 0.0f, -1.0f);
            this.shape1.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape6 = new ModelRenderer((ModelBase)this, 0, 5)).func_78793_a(-5.0f, 5.0f, -1.0f);
            this.shape6.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape14 = new ModelRenderer((ModelBase)this, 0, 13)).func_78793_a(-5.0f, 13.0f, -1.0f);
            this.shape14.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape10 = new ModelRenderer((ModelBase)this, 0, 9)).func_78793_a(-5.0f, 9.0f, -1.0f);
            this.shape10.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape13 = new ModelRenderer((ModelBase)this, 0, 12)).func_78793_a(-5.0f, 12.0f, -1.0f);
            this.shape13.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape4 = new ModelRenderer((ModelBase)this, 0, 3)).func_78793_a(-5.0f, 3.0f, -1.0f);
            this.shape4.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape8 = new ModelRenderer((ModelBase)this, 0, 7)).func_78793_a(-5.0f, 7.0f, -1.0f);
            this.shape8.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape16 = new ModelRenderer((ModelBase)this, 0, 15)).func_78793_a(-5.0f, 15.0f, -1.0f);
            this.shape16.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape12 = new ModelRenderer((ModelBase)this, 0, 11)).func_78793_a(-5.0f, 11.0f, -1.0f);
            this.shape12.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape5 = new ModelRenderer((ModelBase)this, 0, 4)).func_78793_a(-5.0f, 4.0f, -1.0f);
            this.shape5.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape11 = new ModelRenderer((ModelBase)this, 0, 10)).func_78793_a(-5.0f, 10.0f, -1.0f);
            this.shape11.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            (this.shape2 = new ModelRenderer((ModelBase)this, 0, 1)).func_78793_a(-5.0f, 1.0f, -1.0f);
            this.shape2.func_78790_a(0.0f, 0.0f, 0.0f, 10, 1, 1, 0.0f);
            this.field_78092_r.add(this.shape1);
            this.field_78092_r.add(this.shape2);
            this.field_78092_r.add(this.shape3);
            this.field_78092_r.add(this.shape4);
            this.field_78092_r.add(this.shape5);
            this.field_78092_r.add(this.shape6);
            this.field_78092_r.add(this.shape7);
            this.field_78092_r.add(this.shape8);
            this.field_78092_r.add(this.shape9);
            this.field_78092_r.add(this.shape10);
            this.field_78092_r.add(this.shape11);
            this.field_78092_r.add(this.shape12);
            this.field_78092_r.add(this.shape13);
            this.field_78092_r.add(this.shape14);
            this.field_78092_r.add(this.shape15);
            this.field_78092_r.add(this.shape16);
        }
        
        public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
            this.shape9.func_78785_a(f5);
            this.shape15.func_78785_a(f5);
            this.shape3.func_78785_a(f5);
            this.shape7.func_78785_a(f5);
            this.shape1.func_78785_a(f5);
            this.shape6.func_78785_a(f5);
            this.shape14.func_78785_a(f5);
            this.shape10.func_78785_a(f5);
            this.shape13.func_78785_a(f5);
            this.shape4.func_78785_a(f5);
            this.shape8.func_78785_a(f5);
            this.shape16.func_78785_a(f5);
            this.shape12.func_78785_a(f5);
            this.shape5.func_78785_a(f5);
            this.shape11.func_78785_a(f5);
            this.shape2.func_78785_a(f5);
        }
        
        public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }
    }
}
