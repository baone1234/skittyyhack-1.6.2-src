// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.client;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagInt;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.util.ResourceLocation;
import me.earth.phobos.features.modules.Module;

public class ShoulderEntity extends Module
{
    private static final ResourceLocation BLACK_OCELOT_TEXTURES;
    
    public ShoulderEntity() {
        super("ShoulderEntity", "Test", Category.CLIENT, true, false, false);
    }
    
    @Override
    public void onEnable() {
        ShoulderEntity.mc.field_71441_e.func_73027_a(-101, (Entity)new EntityOcelot((World)ShoulderEntity.mc.field_71441_e));
        final NBTTagCompound tag = new NBTTagCompound();
        tag.func_74782_a("id", (NBTBase)new NBTTagInt(-101));
        ShoulderEntity.mc.field_71439_g.func_192027_g(tag);
    }
    
    @Override
    public void onDisable() {
        ShoulderEntity.mc.field_71441_e.func_73028_b(-101);
    }
    
    @SubscribeEvent
    public void onRenderPlayer(final RenderPlayerEvent.Post event) {
    }
    
    public float interpolate(final float yaw1, final float yaw2, final float percent) {
        float rotation = (yaw1 + (yaw2 - yaw1) * percent) % 360.0f;
        if (rotation < 0.0f) {
            rotation += 360.0f;
        }
        return rotation;
    }
    
    static {
        BLACK_OCELOT_TEXTURES = new ResourceLocation("textures/entity/cat/black.png");
    }
}
