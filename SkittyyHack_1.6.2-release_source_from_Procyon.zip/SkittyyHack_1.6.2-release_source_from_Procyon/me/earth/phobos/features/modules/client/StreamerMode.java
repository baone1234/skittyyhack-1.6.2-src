// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.client;

import java.awt.FontMetrics;
import java.awt.Toolkit;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JPanel;
import java.awt.Component;
import javax.swing.JFrame;
import java.util.Iterator;
import java.util.Map;
import me.earth.phobos.util.EntityUtil;
import net.minecraft.potion.PotionEffect;
import me.earth.phobos.util.TextUtil;
import java.util.Date;
import java.text.SimpleDateFormat;
import me.earth.phobos.Phobos;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.awt.EventQueue;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class StreamerMode extends Module
{
    private SecondScreenFrame window;
    public Setting<Integer> width;
    public Setting<Integer> height;
    
    public StreamerMode() {
        super("StreamerMode", "Displays client info in a second window.", Category.CLIENT, false, false, false);
        this.window = null;
        this.width = (Setting<Integer>)this.register(new Setting("Width", (T)600, (T)100, (T)3160));
        this.height = (Setting<Integer>)this.register(new Setting("Height", (T)900, (T)100, (T)2140));
    }
    
    @Override
    public void onEnable() {
        EventQueue.invokeLater(() -> {
            if (this.window == null) {
                this.window = new SecondScreenFrame();
            }
            this.window.setVisible(true);
        });
    }
    
    @Override
    public void onDisable() {
        if (this.window != null) {
            this.window.setVisible(false);
        }
        this.window = null;
    }
    
    @Override
    public void onLogout() {
        if (this.window != null) {
            final ArrayList<String> drawInfo = new ArrayList<String>();
            drawInfo.add("SkittyyHack 1.6.2");
            drawInfo.add("");
            drawInfo.add("No Connection.");
            this.window.setToDraw(drawInfo);
        }
    }
    
    @Override
    public void onUnload() {
        this.disable();
    }
    
    @Override
    public void onLoad() {
        this.disable();
    }
    
    @Override
    public void onUpdate() {
        if (this.window != null) {
            final ArrayList<String> drawInfo = new ArrayList<String>();
            drawInfo.add("SkittyyHack 1.6.2");
            drawInfo.add("");
            drawInfo.add("Fps: " + Minecraft.field_71470_ab);
            drawInfo.add("TPS: " + Phobos.serverManager.getTPS());
            drawInfo.add("Ping: " + Phobos.serverManager.getPing() + "ms");
            drawInfo.add("Speed: " + Phobos.speedManager.getSpeedKpH() + "km/h");
            drawInfo.add("Time: " + new SimpleDateFormat("h:mm a").format(new Date()));
            final boolean inHell = StreamerMode.mc.field_71441_e.func_180494_b(StreamerMode.mc.field_71439_g.func_180425_c()).func_185359_l().equals("Hell");
            final int posX = (int)StreamerMode.mc.field_71439_g.field_70165_t;
            final int posY = (int)StreamerMode.mc.field_71439_g.field_70163_u;
            final int posZ = (int)StreamerMode.mc.field_71439_g.field_70161_v;
            final float nether = inHell ? 8.0f : 0.125f;
            final int hposX = (int)(StreamerMode.mc.field_71439_g.field_70165_t * nether);
            final int hposZ = (int)(StreamerMode.mc.field_71439_g.field_70161_v * nether);
            final String coordinates = "XYZ " + posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]";
            final String text = Phobos.rotationManager.getDirection4D(false);
            drawInfo.add("");
            drawInfo.add(text);
            drawInfo.add(coordinates);
            drawInfo.add("");
            for (final Module module : Phobos.moduleManager.sortedModules) {
                final String moduleName = TextUtil.stripColor(module.getFullArrayString());
                drawInfo.add(moduleName);
            }
            drawInfo.add("");
            for (final PotionEffect effect : Phobos.potionManager.getOwnPotions()) {
                final String potionText = TextUtil.stripColor(Phobos.potionManager.getColoredPotionString(effect));
                drawInfo.add(potionText);
            }
            drawInfo.add("");
            final Map<String, Integer> map = EntityUtil.getTextRadarPlayers();
            if (!map.isEmpty()) {
                for (final Map.Entry<String, Integer> player : map.entrySet()) {
                    final String playerText = TextUtil.stripColor(player.getKey());
                    drawInfo.add(playerText);
                }
            }
            this.window.setToDraw(drawInfo);
        }
    }
    
    public class SecondScreenFrame extends JFrame
    {
        private SecondScreen panel;
        
        public SecondScreenFrame() {
            this.initUI();
        }
        
        private void initUI() {
            this.add(this.panel = new SecondScreen());
            this.setResizable(true);
            this.pack();
            this.setTitle("Phobos - Info");
            this.setLocationRelativeTo(null);
            this.setDefaultCloseOperation(2);
        }
        
        public void setToDraw(final ArrayList<String> list) {
            this.panel.setToDraw(list);
        }
    }
    
    public class SecondScreen extends JPanel
    {
        private final int B_WIDTH;
        private final int B_HEIGHT;
        private Font font;
        private ArrayList<String> toDraw;
        
        public void setToDraw(final ArrayList<String> list) {
            this.toDraw = list;
            this.repaint();
        }
        
        @Override
        public void setFont(final Font font) {
            this.font = font;
        }
        
        public SecondScreen() {
            this.B_WIDTH = StreamerMode.this.width.getValue();
            this.B_HEIGHT = StreamerMode.this.height.getValue();
            this.font = new Font("Verdana", 0, 20);
            this.toDraw = new ArrayList<String>();
            this.initBoard();
        }
        
        public void setWindowSize(final int width, final int height) {
            this.setPreferredSize(new Dimension(width, height));
        }
        
        private void initBoard() {
            this.setBackground(Color.black);
            this.setFocusable(true);
            this.setPreferredSize(new Dimension(this.B_WIDTH, this.B_HEIGHT));
        }
        
        public void paintComponent(final Graphics g) {
            super.paintComponent(g);
            this.drawScreen(g);
        }
        
        private void drawScreen(final Graphics g) {
            final Font small = this.font;
            final FontMetrics metr = this.getFontMetrics(small);
            g.setColor(Color.white);
            g.setFont(small);
            int y = 40;
            for (final String msg : this.toDraw) {
                g.drawString(msg, (this.getWidth() - metr.stringWidth(msg)) / 2, y);
                y += 20;
            }
            Toolkit.getDefaultToolkit().sync();
        }
    }
}
