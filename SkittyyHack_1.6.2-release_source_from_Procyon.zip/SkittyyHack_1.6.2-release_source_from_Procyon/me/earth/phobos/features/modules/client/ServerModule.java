// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.client;

import java.util.Iterator;
import me.earth.phobos.mixin.mixins.accessors.IC00Handshake;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketKeepAlive;
import me.earth.phobos.util.TextUtil;
import net.minecraft.network.play.server.SPacketChat;
import me.earth.phobos.event.events.PacketEvent;
import net.minecraft.network.play.client.CPacketKeepAlive;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketChatMessage;
import java.util.ArrayList;
import java.util.List;
import me.earth.phobos.util.Timer;
import java.util.concurrent.atomic.AtomicBoolean;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class ServerModule extends Module
{
    public Setting<String> ip;
    public Setting<String> port;
    public Setting<String> serverIP;
    public Setting<Boolean> noFML;
    public Setting<Boolean> getName;
    public Setting<Boolean> average;
    public Setting<Boolean> clear;
    public Setting<Boolean> oneWay;
    public Setting<Integer> delay;
    private static ServerModule instance;
    private final AtomicBoolean connected;
    private final Timer pingTimer;
    private long currentPing;
    private long serverPing;
    private StringBuffer name;
    private long averagePing;
    private final List<Long> pingList;
    
    public ServerModule() {
        super("PingBypass", "Manages Phobos`s internal Server", Category.CLIENT, false, false, true);
        this.ip = (Setting<String>)this.register(new Setting("PhobosIP", (T)"0.0.0.0.0"));
        this.port = (Setting<String>)this.register(new Setting<String>("Port", "0").setRenderName(true));
        this.serverIP = (Setting<String>)this.register(new Setting("ServerIP", (T)"AnarchyHvH.eu"));
        this.noFML = (Setting<Boolean>)this.register(new Setting("RemoveFML", (T)false));
        this.getName = (Setting<Boolean>)this.register(new Setting("GetName", (T)false));
        this.average = (Setting<Boolean>)this.register(new Setting("Average", (T)false));
        this.clear = (Setting<Boolean>)this.register(new Setting("ClearPings", (T)false));
        this.oneWay = (Setting<Boolean>)this.register(new Setting("OneWay", (T)false));
        this.delay = (Setting<Integer>)this.register(new Setting("KeepAlives", (T)10, (T)1, (T)50));
        this.connected = new AtomicBoolean(false);
        this.pingTimer = new Timer();
        this.currentPing = 0L;
        this.serverPing = 0L;
        this.name = null;
        this.averagePing = 0L;
        this.pingList = new ArrayList<Long>();
        ServerModule.instance = this;
    }
    
    public String getPlayerName() {
        if (this.name == null) {
            return null;
        }
        return this.name.toString();
    }
    
    public static ServerModule getInstance() {
        if (ServerModule.instance == null) {
            ServerModule.instance = new ServerModule();
        }
        return ServerModule.instance;
    }
    
    @Override
    public void onLogout() {
        this.averagePing = 0L;
        this.currentPing = 0L;
        this.serverPing = 0L;
        this.pingList.clear();
        this.connected.set(false);
        this.name = null;
    }
    
    @Override
    public void onTick() {
        if (ServerModule.mc.func_147114_u() != null && this.isConnected()) {
            if (this.getName.getValue()) {
                ServerModule.mc.func_147114_u().func_147297_a((Packet)new CPacketChatMessage("@Servername"));
                this.getName.setValue(false);
            }
            if (this.pingTimer.passedMs(this.delay.getValue() * 1000)) {
                ServerModule.mc.func_147114_u().func_147297_a((Packet)new CPacketKeepAlive(100L));
                this.pingTimer.reset();
            }
            if (this.clear.getValue()) {
                this.pingList.clear();
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketChat) {
            final SPacketChat packetChat = event.getPacket();
            if (packetChat.func_148915_c().func_150254_d().startsWith("@Client")) {
                this.name = new StringBuffer(TextUtil.stripColor(packetChat.func_148915_c().func_150254_d().replace("@Client", "")));
                event.setCanceled(true);
            }
        }
        else if (event.getPacket() instanceof SPacketKeepAlive) {
            final SPacketKeepAlive alive = event.getPacket();
            if (alive.func_149134_c() != 0L && alive.func_149134_c() < 1000L) {
                this.serverPing = alive.func_149134_c();
                if (this.oneWay.getValue()) {
                    this.currentPing = this.pingTimer.getPassedTimeMs() / 2L;
                }
                else {
                    this.currentPing = this.pingTimer.getPassedTimeMs();
                }
                this.pingList.add(this.currentPing);
                this.averagePing = this.getAveragePing();
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getPacket() instanceof C00Handshake) {
            final IC00Handshake packet = event.getPacket();
            final String ip = packet.getIp();
            if (ip.equals(this.ip.getValue())) {
                packet.setIp(this.serverIP.getValue());
                System.out.println(packet.getIp());
                this.connected.set(true);
            }
        }
    }
    
    @Override
    public String getDisplayInfo() {
        return this.averagePing + "ms";
    }
    
    private long getAveragePing() {
        if (!this.average.getValue() || this.pingList.isEmpty()) {
            return this.currentPing;
        }
        int full = 0;
        for (final long i : this.pingList) {
            full += (int)i;
        }
        return full / this.pingList.size();
    }
    
    public boolean isConnected() {
        return this.connected.get();
    }
    
    public int getPort() {
        int result;
        try {
            result = Integer.parseInt(this.port.getValue());
        }
        catch (NumberFormatException e) {
            return -1;
        }
        return result;
    }
    
    public long getServerPing() {
        return this.serverPing;
    }
}
