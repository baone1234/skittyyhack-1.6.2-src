// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.client;

import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class Screens extends Module
{
    public Setting<Boolean> mainScreen;
    public static Screens INSTANCE;
    
    public Screens() {
        super("Screens", "Controls custom screens used by the client", Category.CLIENT, true, false, false);
        this.mainScreen = (Setting<Boolean>)this.register(new Setting("MainScreen", (T)true));
        Screens.INSTANCE = this;
    }
    
    @Override
    public void onTick() {
    }
}
