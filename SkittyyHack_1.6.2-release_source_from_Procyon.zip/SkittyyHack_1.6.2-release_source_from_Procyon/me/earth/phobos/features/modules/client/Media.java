// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.client;

import me.earth.phobos.features.Feature;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class Media extends Module
{
    public final Setting<Boolean> changeOwn;
    public final Setting<String> ownName;
    private static Media instance;
    
    public Media() {
        super("Media", "Helps with creating Media", Category.CLIENT, false, false, false);
        this.changeOwn = (Setting<Boolean>)this.register(new Setting("MyName", (T)true));
        this.ownName = (Setting<String>)this.register(new Setting("Name", (T)"Name here...", v -> this.changeOwn.getValue()));
        Media.instance = this;
    }
    
    public static Media getInstance() {
        if (Media.instance == null) {
            Media.instance = new Media();
        }
        return Media.instance;
    }
    
    public static String getPlayerName() {
        if (Feature.fullNullCheck() || !ServerModule.getInstance().isConnected()) {
            return Media.mc.func_110432_I().func_111285_a();
        }
        final String name = ServerModule.getInstance().getPlayerName();
        if (name == null || name.isEmpty()) {
            return Media.mc.func_110432_I().func_111285_a();
        }
        return name;
    }
}
