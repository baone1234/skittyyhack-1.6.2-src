// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.render;

import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelRenderer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.client.model.ModelBase;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.GlStateManager;
import me.earth.phobos.Phobos;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraft.util.ResourceLocation;
import me.earth.phobos.features.modules.Module;

public class Cosmetics extends Module
{
    public final TopHatModel hatModel;
    public final GlassesModel glassesModel;
    private final HatGlassesModel hatGlassesModel;
    public final SantaHatModel santaHatModel;
    public final ModelHatFez fezModel;
    private final ResourceLocation hatTexture;
    private final ResourceLocation fezTexture;
    private final ResourceLocation glassesTexture;
    private final ResourceLocation santaHatTexture;
    public static Cosmetics INSTANCE;
    
    public Cosmetics() {
        super("Cosmetics", "Bitch", Category.RENDER, true, false, false);
        this.hatModel = new TopHatModel();
        this.glassesModel = new GlassesModel();
        this.hatGlassesModel = new HatGlassesModel();
        this.santaHatModel = new SantaHatModel();
        this.fezModel = new ModelHatFez();
        this.hatTexture = new ResourceLocation("textures/tophat.png");
        this.fezTexture = new ResourceLocation("textures/fez.png");
        this.glassesTexture = new ResourceLocation("textures/sunglasses.png");
        this.santaHatTexture = new ResourceLocation("textures/santahat.png");
        Cosmetics.INSTANCE = this;
    }
    
    @SubscribeEvent
    public void onRenderPlayer(final RenderPlayerEvent.Post event) {
        if (!Phobos.cosmeticsManager.hasCosmetics(event.getEntityPlayer())) {
            return;
        }
        GlStateManager.func_179094_E();
        final RenderManager renderManager = Cosmetics.mc.func_175598_ae();
        GlStateManager.func_179137_b(event.getX(), event.getY(), event.getZ());
        final double scale = 1.0;
        final double rotate = this.interpolate(event.getEntityPlayer().field_70758_at, event.getEntityPlayer().field_70759_as, event.getPartialRenderTick());
        final double rotate2 = this.interpolate(event.getEntityPlayer().field_70127_C, event.getEntityPlayer().field_70125_A, event.getPartialRenderTick());
        GL11.glScaled(-scale, -scale, scale);
        GL11.glTranslated(0.0, -(event.getEntityPlayer().field_70131_O - (event.getEntityPlayer().func_70093_af() ? 0.25 : 0.0) - 0.38) / scale, 0.0);
        GL11.glRotated(180.0 + rotate, 0.0, 1.0, 0.0);
        GL11.glRotated(rotate2, 1.0, 0.0, 0.0);
        GlStateManager.func_179137_b(0.0, -0.45, 0.0);
        for (final ModelBase model : Phobos.cosmeticsManager.getRenderModels(event.getEntityPlayer())) {
            if (model instanceof TopHatModel) {
                Cosmetics.mc.func_110434_K().func_110577_a(this.hatTexture);
                this.hatModel.func_78088_a(event.getEntity(), 0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
                Cosmetics.mc.func_110434_K().func_147645_c(this.hatTexture);
            }
            else if (model instanceof GlassesModel) {
                if (event.getEntityPlayer().func_175148_a(EnumPlayerModelParts.HAT)) {
                    Cosmetics.mc.func_110434_K().func_110577_a(this.glassesTexture);
                    this.hatGlassesModel.func_78088_a(event.getEntity(), 0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
                    Cosmetics.mc.func_110434_K().func_147645_c(this.glassesTexture);
                }
                else {
                    Cosmetics.mc.func_110434_K().func_110577_a(this.glassesTexture);
                    this.glassesModel.func_78088_a(event.getEntity(), 0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
                    Cosmetics.mc.func_110434_K().func_147645_c(this.glassesTexture);
                }
            }
            else {
                if (!(model instanceof SantaHatModel)) {
                    continue;
                }
                Cosmetics.mc.func_110434_K().func_110577_a(this.santaHatTexture);
                this.santaHatModel.func_78088_a(event.getEntity(), 0.0f, 0.0f, -0.1f, 0.0f, 0.0f, 0.0625f);
                Cosmetics.mc.func_110434_K().func_147645_c(this.santaHatTexture);
            }
        }
        GlStateManager.func_179121_F();
    }
    
    public float interpolate(final float yaw1, final float yaw2, final float percent) {
        float rotation = (yaw1 + (yaw2 - yaw1) * percent) % 360.0f;
        if (rotation < 0.0f) {
            rotation += 360.0f;
        }
        return rotation;
    }
    
    public static class ModelHatFez extends ModelBase
    {
        private ModelRenderer baseLayer;
        private ModelRenderer topLayer;
        private ModelRenderer stringLayer;
        private ModelRenderer danglingStringLayer;
        private ModelRenderer otherDanglingStringLayer;
        
        public ModelHatFez() {
            this.field_78090_t = 64;
            this.field_78089_u = 32;
            (this.baseLayer = new ModelRenderer((ModelBase)this, 1, 1)).func_78789_a(-3.0f, 0.0f, -3.0f, 6, 4, 6);
            this.baseLayer.func_78793_a(0.0f, -4.0f, 0.0f);
            this.baseLayer.func_78787_b(this.field_78090_t, this.field_78089_u);
            this.baseLayer.field_78809_i = true;
            this.setRotation(this.baseLayer, 0.0f, 0.12217305f, 0.0f);
            (this.topLayer = new ModelRenderer((ModelBase)this, 1, 1)).func_78789_a(0.0f, 0.0f, 0.0f, 1, 1, 1);
            this.topLayer.func_78793_a(-0.5f, -4.75f, -0.5f);
            this.topLayer.func_78787_b(this.field_78090_t, this.field_78089_u);
            this.topLayer.field_78809_i = true;
            this.setRotation(this.topLayer, 0.0f, 0.0f, 0.0f);
            (this.stringLayer = new ModelRenderer((ModelBase)this, 25, 1)).func_78789_a(-0.5f, -0.5f, -0.5f, 3, 1, 1);
            this.stringLayer.func_78793_a(0.5f, -3.75f, 0.0f);
            this.stringLayer.func_78787_b(this.field_78090_t, this.field_78089_u);
            this.stringLayer.field_78809_i = true;
            this.setRotation(this.stringLayer, 0.7853982f, 0.0f, 0.0f);
            (this.danglingStringLayer = new ModelRenderer((ModelBase)this, 41, 1)).func_78789_a(-0.5f, -0.5f, -0.5f, 3, 1, 1);
            this.danglingStringLayer.func_78793_a(3.0f, -3.5f, 0.0f);
            this.danglingStringLayer.func_78787_b(this.field_78090_t, this.field_78089_u);
            this.danglingStringLayer.field_78809_i = true;
            this.setRotation(this.danglingStringLayer, 0.2268928f, 0.7853982f, 1.2042772f);
            (this.otherDanglingStringLayer = new ModelRenderer((ModelBase)this, 33, 9)).func_78789_a(-0.5f, -0.5f, -0.5f, 3, 1, 1);
            this.otherDanglingStringLayer.func_78793_a(3.0f, -3.5f, 0.0f);
            this.otherDanglingStringLayer.func_78787_b(this.field_78090_t, this.field_78089_u);
            this.otherDanglingStringLayer.field_78809_i = true;
            this.setRotation(this.otherDanglingStringLayer, 0.2268928f, -0.9250245f, 1.2042772f);
        }
        
        public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
            super.func_78088_a(entity, f, f1, f2, f3, f4, f5);
            this.setRotationAngles(f, f1, f2, f3, f4, f5);
            this.baseLayer.func_78785_a(f5);
            this.topLayer.func_78785_a(f5);
            this.stringLayer.func_78785_a(f5);
            this.danglingStringLayer.func_78785_a(f5);
            this.otherDanglingStringLayer.func_78785_a(f5);
        }
        
        private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
            model.field_78795_f = x;
            model.field_78796_g = y;
            model.field_78808_h = z;
        }
        
        public void setRotationAngles(final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
            super.func_78087_a(f, f1, f2, f3, f4, f5, (Entity)null);
        }
    }
    
    public class TopHatModel extends ModelBase
    {
        public final ResourceLocation hatTexture;
        public ModelRenderer bottom;
        public ModelRenderer top;
        
        public TopHatModel() {
            this.hatTexture = new ResourceLocation("textures/tophat.png");
            this.field_78090_t = 64;
            this.field_78089_u = 32;
            (this.top = new ModelRenderer((ModelBase)this, 0, 10)).func_78790_a(0.0f, 0.0f, 0.0f, 4, 10, 4, 0.0f);
            this.top.func_78793_a(-2.0f, -11.0f, -2.0f);
            (this.bottom = new ModelRenderer((ModelBase)this, 0, 0)).func_78790_a(0.0f, 0.0f, 0.0f, 8, 1, 8, 0.0f);
            this.bottom.func_78793_a(-4.0f, -1.0f, -4.0f);
        }
        
        public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
            this.top.func_78785_a(f5);
            this.bottom.func_78785_a(f5);
        }
        
        public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }
    }
    
    public class GlassesModel extends ModelBase
    {
        public final ResourceLocation glassesTexture;
        public ModelRenderer firstLeftFrame;
        public ModelRenderer firstRightFrame;
        public ModelRenderer centerBar;
        public ModelRenderer farLeftBar;
        public ModelRenderer farRightBar;
        public ModelRenderer leftEar;
        public ModelRenderer rightEar;
        
        public GlassesModel() {
            this.glassesTexture = new ResourceLocation("textures/sunglasses.png");
            this.field_78090_t = 64;
            this.field_78089_u = 64;
            (this.farLeftBar = new ModelRenderer((ModelBase)this, 0, 13)).func_78793_a(-4.0f, 3.5f, -4.0f);
            this.farLeftBar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f);
            (this.rightEar = new ModelRenderer((ModelBase)this, 10, 0)).func_78793_a(3.2f, 3.5f, -4.0f);
            this.rightEar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 3, 0.0f);
            (this.centerBar = new ModelRenderer((ModelBase)this, 0, 9)).func_78793_a(-1.0f, 3.5f, -4.0f);
            this.centerBar.func_78790_a(0.0f, 0.0f, 0.0f, 2, 1, 1, 0.0f);
            (this.firstLeftFrame = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-3.0f, 3.0f, -4.0f);
            this.firstLeftFrame.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 1, 0.0f);
            (this.firstRightFrame = new ModelRenderer((ModelBase)this, 0, 5)).func_78793_a(1.0f, 3.0f, -4.0f);
            this.firstRightFrame.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 1, 0.0f);
            (this.leftEar = new ModelRenderer((ModelBase)this, 20, 0)).func_78793_a(-4.2f, 3.5f, -4.0f);
            this.leftEar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 3, 0.0f);
            (this.farRightBar = new ModelRenderer((ModelBase)this, 0, 17)).func_78793_a(3.0f, 3.5f, -4.0f);
            this.farRightBar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f);
        }
        
        public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
            this.farLeftBar.func_78785_a(f5);
            this.rightEar.func_78785_a(f5);
            this.centerBar.func_78785_a(f5);
            this.firstLeftFrame.func_78785_a(f5);
            this.firstRightFrame.func_78785_a(f5);
            this.leftEar.func_78785_a(f5);
            this.farRightBar.func_78785_a(f5);
        }
        
        public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }
    }
    
    public class HatGlassesModel extends ModelBase
    {
        public final ResourceLocation glassesTexture;
        public ModelRenderer firstLeftFrame;
        public ModelRenderer firstRightFrame;
        public ModelRenderer centerBar;
        public ModelRenderer farLeftBar;
        public ModelRenderer farRightBar;
        public ModelRenderer leftEar;
        public ModelRenderer rightEar;
        
        public HatGlassesModel() {
            this.glassesTexture = new ResourceLocation("textures/sunglasses.png");
            this.field_78090_t = 64;
            this.field_78089_u = 64;
            (this.farLeftBar = new ModelRenderer((ModelBase)this, 0, 13)).func_78793_a(-4.0f, 3.5f, -5.0f);
            this.farLeftBar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f);
            (this.rightEar = new ModelRenderer((ModelBase)this, 10, 0)).func_78793_a(3.2f, 3.5f, -5.0f);
            this.rightEar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 3, 0.0f);
            (this.centerBar = new ModelRenderer((ModelBase)this, 0, 9)).func_78793_a(-1.0f, 3.5f, -5.0f);
            this.centerBar.func_78790_a(0.0f, 0.0f, 0.0f, 2, 1, 1, 0.0f);
            (this.firstLeftFrame = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-3.0f, 3.0f, -5.0f);
            this.firstLeftFrame.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 1, 0.0f);
            (this.firstRightFrame = new ModelRenderer((ModelBase)this, 0, 5)).func_78793_a(1.0f, 3.0f, -5.0f);
            this.firstRightFrame.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 1, 0.0f);
            (this.leftEar = new ModelRenderer((ModelBase)this, 20, 0)).func_78793_a(-4.2f, 3.5f, -5.0f);
            this.leftEar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 3, 0.0f);
            (this.farRightBar = new ModelRenderer((ModelBase)this, 0, 17)).func_78793_a(3.0f, 3.5f, -5.0f);
            this.farRightBar.func_78790_a(0.0f, 0.0f, 0.0f, 1, 1, 1, 0.0f);
        }
        
        public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
            this.farLeftBar.func_78785_a(f5);
            this.rightEar.func_78785_a(f5);
            this.centerBar.func_78785_a(f5);
            this.firstLeftFrame.func_78785_a(f5);
            this.firstRightFrame.func_78785_a(f5);
            this.leftEar.func_78785_a(f5);
            this.farRightBar.func_78785_a(f5);
        }
        
        public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }
    }
    
    public class SantaHatModel extends ModelBase
    {
        public ModelRenderer baseLayer;
        public ModelRenderer baseRedLayer;
        public ModelRenderer midRedLayer;
        public ModelRenderer topRedLayer;
        public ModelRenderer lastRedLayer;
        public ModelRenderer realFinalLastLayer;
        public ModelRenderer whiteLayer;
        
        public SantaHatModel() {
            this.field_78090_t = 64;
            this.field_78089_u = 32;
            (this.topRedLayer = new ModelRenderer((ModelBase)this, 46, 0)).func_78793_a(0.5f, -8.4f, -1.5f);
            this.topRedLayer.func_78790_a(0.0f, 0.0f, 0.0f, 3, 2, 3, 0.0f);
            this.setRotateAngle(this.topRedLayer, 0.0f, 0.0f, 0.5009095f);
            (this.baseLayer = new ModelRenderer((ModelBase)this, 0, 0)).func_78793_a(-4.0f, -1.0f, -4.0f);
            this.baseLayer.func_78790_a(0.0f, 0.0f, 0.0f, 8, 2, 8, 0.0f);
            (this.midRedLayer = new ModelRenderer((ModelBase)this, 28, 0)).func_78793_a(-1.2f, -6.8f, -2.0f);
            this.midRedLayer.func_78790_a(0.0f, 0.0f, 0.0f, 4, 3, 4, 0.0f);
            this.setRotateAngle(this.midRedLayer, 0.0f, 0.0f, 0.22759093f);
            (this.realFinalLastLayer = new ModelRenderer((ModelBase)this, 46, 8)).func_78793_a(4.0f, -10.4f, 0.0f);
            this.realFinalLastLayer.func_78790_a(0.0f, 0.0f, 0.0f, 1, 3, 1, 0.0f);
            this.setRotateAngle(this.realFinalLastLayer, 0.0f, 0.0f, 1.0016445f);
            (this.lastRedLayer = new ModelRenderer((ModelBase)this, 34, 8)).func_78793_a(2.0f, -9.4f, 0.0f);
            this.lastRedLayer.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 2, 0.0f);
            this.setRotateAngle(this.lastRedLayer, 0.0f, 0.0f, 0.8196066f);
            (this.whiteLayer = new ModelRenderer((ModelBase)this, 0, 22)).func_78793_a(4.1f, -9.7f, -0.5f);
            this.whiteLayer.func_78790_a(0.0f, 0.0f, 0.0f, 2, 2, 2, 0.0f);
            this.setRotateAngle(this.whiteLayer, -0.091106184f, 0.0f, 0.18203785f);
            (this.baseRedLayer = new ModelRenderer((ModelBase)this, 0, 11)).func_78793_a(-3.0f, -4.0f, -3.0f);
            this.baseRedLayer.func_78790_a(0.0f, 0.0f, 0.0f, 6, 3, 6, 0.0f);
            this.setRotateAngle(this.baseRedLayer, 0.0f, 0.0f, 0.045553092f);
        }
        
        public void func_78088_a(final Entity entity, final float f, final float f1, final float f2, final float f3, final float f4, final float f5) {
            this.topRedLayer.func_78785_a(f5);
            this.baseLayer.func_78785_a(f5);
            this.midRedLayer.func_78785_a(f5);
            this.realFinalLastLayer.func_78785_a(f5);
            this.lastRedLayer.func_78785_a(f5);
            this.whiteLayer.func_78785_a(f5);
            this.baseRedLayer.func_78785_a(f5);
        }
        
        public void setRotateAngle(final ModelRenderer modelRenderer, final float x, final float y, final float z) {
            modelRenderer.field_78795_f = x;
            modelRenderer.field_78796_g = y;
            modelRenderer.field_78808_h = z;
        }
    }
}
