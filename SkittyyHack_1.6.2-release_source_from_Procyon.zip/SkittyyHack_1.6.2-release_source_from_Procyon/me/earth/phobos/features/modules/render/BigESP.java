// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.render;

import java.util.Iterator;
import net.minecraft.entity.player.EntityPlayer;
import me.earth.phobos.features.Feature;
import me.earth.phobos.event.events.Render3DEvent;
import me.earth.phobos.features.modules.Module;

public class BigESP extends Module
{
    public BigESP() {
        super("BigModule", "Big fucking module", Category.RENDER, true, false, false);
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (!Feature.fullNullCheck()) {
            for (final EntityPlayer player : BigESP.mc.field_71441_e.field_73010_i) {
                final double x = this.interpolate(player.field_70142_S, player.field_70165_t, event.getPartialTicks()) - BigESP.mc.func_175598_ae().field_78725_b;
                final double y = this.interpolate(player.field_70137_T, player.field_70163_u, event.getPartialTicks()) - BigESP.mc.func_175598_ae().field_78726_c;
                final double z = this.interpolate(player.field_70136_U, player.field_70161_v, event.getPartialTicks()) - BigESP.mc.func_175598_ae().field_78723_d;
                this.renderBigESP(player, x, y, z, event.getPartialTicks());
            }
        }
    }
    
    public void renderBigESP(final EntityPlayer player, final double x, final double y, final double z, final float delta) {
    }
    
    private double interpolate(final double previous, final double current, final float delta) {
        return previous + (current - previous) * delta;
    }
}
