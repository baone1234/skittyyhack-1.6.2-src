// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.render;

import java.util.Iterator;
import net.minecraft.util.math.RayTraceResult;
import java.util.List;
import net.minecraft.client.renderer.entity.RenderManager;
import me.earth.phobos.Phobos;
import net.minecraft.entity.Entity;
import me.earth.phobos.util.EntityUtil;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.awt.Color;
import me.earth.phobos.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import me.earth.phobos.event.events.Render3DEvent;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class Ranges extends Module
{
    private final Setting<Boolean> hitSpheres;
    private final Setting<Boolean> circle;
    private final Setting<Boolean> ownSphere;
    private final Setting<Boolean> raytrace;
    private final Setting<Float> lineWidth;
    private final Setting<Double> radius;
    
    public Ranges() {
        super("Ranges", "Draws a circle around the player.", Category.RENDER, false, false, false);
        this.hitSpheres = (Setting<Boolean>)this.register(new Setting("HitSpheres", (T)false));
        this.circle = (Setting<Boolean>)this.register(new Setting("Circle", (T)true));
        this.ownSphere = (Setting<Boolean>)this.register(new Setting("OwnSphere", (T)false, v -> this.hitSpheres.getValue()));
        this.raytrace = (Setting<Boolean>)this.register(new Setting("RayTrace", (T)false, v -> this.circle.getValue()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", (T)1.5f, (T)0.1f, (T)5.0f));
        this.radius = (Setting<Double>)this.register(new Setting("Radius", (T)4.5, (T)0.1, (T)8.0));
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (this.circle.getValue()) {
            GlStateManager.func_179094_E();
            RenderUtil.GLPre(this.lineWidth.getValue());
            GlStateManager.func_179147_l();
            GlStateManager.func_187441_d(3.0f);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a(false);
            GlStateManager.func_179097_i();
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            final RenderManager renderManager = Ranges.mc.func_175598_ae();
            final Color color = Color.RED;
            final List<Vec3d> hVectors = new ArrayList<Vec3d>();
            final double x = Ranges.mc.field_71439_g.field_70142_S + (Ranges.mc.field_71439_g.field_70165_t - Ranges.mc.field_71439_g.field_70142_S) * event.getPartialTicks() - renderManager.field_78725_b;
            final double y = Ranges.mc.field_71439_g.field_70137_T + (Ranges.mc.field_71439_g.field_70163_u - Ranges.mc.field_71439_g.field_70137_T) * event.getPartialTicks() - renderManager.field_78726_c;
            final double z = Ranges.mc.field_71439_g.field_70136_U + (Ranges.mc.field_71439_g.field_70161_v - Ranges.mc.field_71439_g.field_70136_U) * event.getPartialTicks() - renderManager.field_78723_d;
            GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, color.getAlpha() / 255.0f);
            GL11.glLineWidth((float)this.lineWidth.getValue());
            GL11.glBegin(1);
            for (int i = 0; i <= 360; ++i) {
                final Vec3d vec = new Vec3d(x + Math.sin(i * 3.141592653589793 / 180.0) * this.radius.getValue(), y + 0.1, z + Math.cos(i * 3.141592653589793 / 180.0) * this.radius.getValue());
                final RayTraceResult result = Ranges.mc.field_71441_e.func_147447_a(new Vec3d(x, y + 0.1, z), vec, false, true, false);
                if (result != null && this.raytrace.getValue()) {
                    hVectors.add(result.field_72307_f);
                }
                else {
                    hVectors.add(vec);
                }
            }
            for (int j = 0; j < hVectors.size() - 1; ++j) {
                GL11.glVertex3d(hVectors.get(j).field_72450_a, hVectors.get(j).field_72448_b, hVectors.get(j).field_72449_c);
                GL11.glVertex3d(hVectors.get(j + 1).field_72450_a, hVectors.get(j + 1).field_72448_b, hVectors.get(j + 1).field_72449_c);
            }
            GL11.glEnd();
            GlStateManager.func_179117_G();
            GlStateManager.func_179126_j();
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            RenderUtil.GlPost();
            GlStateManager.func_179121_F();
        }
        if (this.hitSpheres.getValue()) {
            for (final EntityPlayer player : Ranges.mc.field_71441_e.field_73010_i) {
                if (player != null && (!player.equals((Object)Ranges.mc.field_71439_g) || this.ownSphere.getValue())) {
                    final Vec3d interpolated = EntityUtil.interpolateEntity((Entity)player, event.getPartialTicks());
                    if (Phobos.friendManager.isFriend(player.func_70005_c_())) {
                        GL11.glColor4f(0.15f, 0.15f, 1.0f, 1.0f);
                    }
                    else if (Ranges.mc.field_71439_g.func_70032_d((Entity)player) >= 64.0f) {
                        GL11.glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
                    }
                    else {
                        GL11.glColor4f(1.0f, Ranges.mc.field_71439_g.func_70032_d((Entity)player) / 150.0f, 0.0f, 1.0f);
                    }
                    RenderUtil.drawSphere(interpolated.field_72450_a, interpolated.field_72448_b, interpolated.field_72449_c, this.radius.getValue().floatValue(), 20, 15);
                }
            }
        }
    }
}
