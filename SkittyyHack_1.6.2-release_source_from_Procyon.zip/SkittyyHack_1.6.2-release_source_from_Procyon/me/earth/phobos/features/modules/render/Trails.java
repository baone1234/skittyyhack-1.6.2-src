// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.render;

import org.lwjgl.opengl.GL11;
import me.earth.phobos.util.RenderUtil;
import net.minecraft.client.renderer.GlStateManager;
import me.earth.phobos.event.events.Render3DEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import java.util.ArrayList;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
import java.util.HashMap;
import net.minecraft.util.math.Vec3d;
import java.util.List;
import net.minecraft.entity.Entity;
import java.util.Map;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class Trails extends Module
{
    private final Setting<Float> lineWidth;
    private final Setting<Integer> red;
    private final Setting<Integer> green;
    private final Setting<Integer> blue;
    private final Setting<Integer> alpha;
    private Map<Entity, List<Vec3d>> renderMap;
    
    public Trails() {
        super("Trails", "Draws trails on projectiles", Category.RENDER, true, false, false);
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", (T)1.5f, (T)0.1f, (T)5.0f));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)0, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)0, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255));
        this.renderMap = new HashMap<Entity, List<Vec3d>>();
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent event) {
        for (final Entity entity : Trails.mc.field_71441_e.field_72996_f) {
            if (entity instanceof EntityThrowable || entity instanceof EntityArrow) {
                List<Vec3d> vectors;
                if (this.renderMap.get(entity) != null) {
                    vectors = this.renderMap.get(entity);
                }
                else {
                    vectors = new ArrayList<Vec3d>();
                }
                vectors.add(new Vec3d(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
                this.renderMap.put(entity, vectors);
            }
        }
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        for (final Entity entity : Trails.mc.field_71441_e.field_72996_f) {
            if (!this.renderMap.containsKey(entity)) {
                continue;
            }
            GlStateManager.func_179094_E();
            RenderUtil.GLPre(this.lineWidth.getValue());
            GlStateManager.func_179147_l();
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a(false);
            GlStateManager.func_179097_i();
            GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GL11.glColor4f(this.red.getValue() / 255.0f, this.green.getValue() / 255.0f, this.blue.getValue() / 255.0f, this.alpha.getValue() / 255.0f);
            GL11.glLineWidth((float)this.lineWidth.getValue());
            GL11.glBegin(1);
            for (int i = 0; i < this.renderMap.get(entity).size() - 1; ++i) {
                GL11.glVertex3d(this.renderMap.get(entity).get(i).field_72450_a, this.renderMap.get(entity).get(i).field_72448_b, this.renderMap.get(entity).get(i).field_72449_c);
                GL11.glVertex3d(this.renderMap.get(entity).get(i + 1).field_72450_a, this.renderMap.get(entity).get(i + 1).field_72448_b, this.renderMap.get(entity).get(i + 1).field_72449_c);
            }
            GL11.glEnd();
            GlStateManager.func_179117_G();
            GlStateManager.func_179126_j();
            GlStateManager.func_179132_a(true);
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            RenderUtil.GlPost();
            GlStateManager.func_179121_F();
        }
    }
}
