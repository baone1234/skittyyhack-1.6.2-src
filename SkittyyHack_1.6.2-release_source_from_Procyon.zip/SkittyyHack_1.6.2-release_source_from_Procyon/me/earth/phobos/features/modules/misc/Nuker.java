// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.misc;

import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.World;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import java.util.List;
import net.minecraft.util.math.BlockPos;
import net.minecraft.init.Blocks;
import java.util.ArrayList;
import me.earth.phobos.util.BlockUtil;
import net.minecraft.util.EnumHand;
import me.earth.phobos.Phobos;
import me.earth.phobos.util.MathUtil;
import net.minecraft.util.math.Vec3d;
import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.earth.phobos.event.events.BlockEvent;
import net.minecraft.block.Block;
import me.earth.phobos.util.Timer;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class Nuker extends Module
{
    public Setting<Boolean> rotate;
    public Setting<Float> distance;
    public Setting<Integer> blockPerTick;
    public Setting<Integer> delay;
    public Setting<Boolean> nuke;
    public Setting<Mode> mode;
    public Setting<Boolean> antiRegear;
    public Setting<Boolean> hopperNuker;
    private Setting<Boolean> autoSwitch;
    private int oldSlot;
    private boolean isMining;
    private final Timer timer;
    private Block selected;
    
    public Nuker() {
        super("Nuker", "Mines many blocks", Category.MISC, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.distance = (Setting<Float>)this.register(new Setting("Range", (T)6.0f, (T)0.1f, (T)10.0f));
        this.blockPerTick = (Setting<Integer>)this.register(new Setting("Blocks/Attack", (T)50, (T)1, (T)100));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay/Attack", (T)50, (T)1, (T)1000));
        this.nuke = (Setting<Boolean>)this.register(new Setting("Nuke", (T)false));
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.NUKE, v -> this.nuke.getValue()));
        this.antiRegear = (Setting<Boolean>)this.register(new Setting("AntiRegear", (T)false));
        this.hopperNuker = (Setting<Boolean>)this.register(new Setting("HopperAura", (T)false));
        this.autoSwitch = (Setting<Boolean>)this.register(new Setting("AutoSwitch", (T)false));
        this.oldSlot = -1;
        this.isMining = false;
        this.timer = new Timer();
    }
    
    @Override
    public void onToggle() {
        this.selected = null;
    }
    
    @SubscribeEvent
    public void onClickBlock(final BlockEvent event) {
        if (event.getStage() == 3 && (this.mode.getValue() == Mode.SELECTION || this.mode.getValue() == Mode.NUKE)) {
            final Block block = Nuker.mc.field_71441_e.func_180495_p(event.pos).func_177230_c();
            if (block != null && block != this.selected) {
                this.selected = block;
                event.setCanceled(true);
            }
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayerPre(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 0) {
            if (this.nuke.getValue()) {
                BlockPos pos = null;
                switch (this.mode.getValue()) {
                    case SELECTION:
                    case NUKE: {
                        pos = this.getClosestBlockSelection();
                        break;
                    }
                    case ALL: {
                        pos = this.getClosestBlockAll();
                        break;
                    }
                }
                if (pos != null) {
                    if (this.mode.getValue() == Mode.SELECTION || this.mode.getValue() == Mode.ALL) {
                        if (this.rotate.getValue()) {
                            final float[] angle = MathUtil.calcAngle(Nuker.mc.field_71439_g.func_174824_e(Nuker.mc.func_184121_ak()), new Vec3d((double)(pos.func_177958_n() + 0.5f), (double)(pos.func_177956_o() + 0.5f), (double)(pos.func_177952_p() + 0.5f)));
                            Phobos.rotationManager.setPlayerRotations(angle[0], angle[1]);
                        }
                        if (this.canBreak(pos)) {
                            Nuker.mc.field_71442_b.func_180512_c(pos, Nuker.mc.field_71439_g.func_174811_aO());
                            Nuker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        }
                    }
                    else {
                        for (int i = 0; i < this.blockPerTick.getValue(); ++i) {
                            pos = this.getClosestBlockSelection();
                            if (pos != null) {
                                if (this.rotate.getValue()) {
                                    final float[] angle2 = MathUtil.calcAngle(Nuker.mc.field_71439_g.func_174824_e(Nuker.mc.func_184121_ak()), new Vec3d((double)(pos.func_177958_n() + 0.5f), (double)(pos.func_177956_o() + 0.5f), (double)(pos.func_177952_p() + 0.5f)));
                                    Phobos.rotationManager.setPlayerRotations(angle2[0], angle2[1]);
                                }
                                if (this.timer.passedMs(this.delay.getValue())) {
                                    Nuker.mc.field_71442_b.func_180512_c(pos, Nuker.mc.field_71439_g.func_174811_aO());
                                    Nuker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                                    this.timer.reset();
                                }
                            }
                        }
                    }
                }
            }
            if (this.antiRegear.getValue()) {
                this.breakBlocks(BlockUtil.shulkerList);
            }
            if (this.hopperNuker.getValue()) {
                final List<Block> blocklist = new ArrayList<Block>();
                blocklist.add((Block)Blocks.field_150438_bZ);
                this.breakBlocks(blocklist);
            }
        }
    }
    
    public void breakBlocks(final List<Block> blocks) {
        final BlockPos pos = this.getNearestBlock(blocks);
        if (pos != null) {
            if (!this.isMining) {
                this.oldSlot = Nuker.mc.field_71439_g.field_71071_by.field_70461_c;
                this.isMining = true;
            }
            if (this.rotate.getValue()) {
                final float[] angle = MathUtil.calcAngle(Nuker.mc.field_71439_g.func_174824_e(Nuker.mc.func_184121_ak()), new Vec3d((double)(pos.func_177958_n() + 0.5f), (double)(pos.func_177956_o() + 0.5f), (double)(pos.func_177952_p() + 0.5f)));
                Phobos.rotationManager.setPlayerRotations(angle[0], angle[1]);
            }
            if (this.canBreak(pos)) {
                if (this.autoSwitch.getValue()) {
                    int newSlot = -1;
                    for (int i = 0; i < 9; ++i) {
                        final ItemStack stack = Nuker.mc.field_71439_g.field_71071_by.func_70301_a(i);
                        if (stack != ItemStack.field_190927_a) {
                            if (stack.func_77973_b() instanceof ItemPickaxe) {
                                newSlot = i;
                                break;
                            }
                        }
                    }
                    if (newSlot != -1) {
                        Nuker.mc.field_71439_g.field_71071_by.field_70461_c = newSlot;
                    }
                }
                Nuker.mc.field_71442_b.func_180512_c(pos, Nuker.mc.field_71439_g.func_174811_aO());
                Nuker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            }
        }
        else if (this.autoSwitch.getValue() && this.oldSlot != -1) {
            Nuker.mc.field_71439_g.field_71071_by.field_70461_c = this.oldSlot;
            this.oldSlot = -1;
            this.isMining = false;
        }
    }
    
    private boolean canBreak(final BlockPos pos) {
        final IBlockState blockState = Nuker.mc.field_71441_e.func_180495_p(pos);
        final Block block = blockState.func_177230_c();
        return block.func_176195_g(blockState, (World)Nuker.mc.field_71441_e, pos) != -1.0f;
    }
    
    private BlockPos getNearestBlock(final List<Block> blocks) {
        double maxDist = MathUtil.square(this.distance.getValue());
        BlockPos ret = null;
        for (double x = maxDist; x >= -maxDist; --x) {
            for (double y = maxDist; y >= -maxDist; --y) {
                for (double z = maxDist; z >= -maxDist; --z) {
                    final BlockPos pos = new BlockPos(Nuker.mc.field_71439_g.field_70165_t + x, Nuker.mc.field_71439_g.field_70163_u + y, Nuker.mc.field_71439_g.field_70161_v + z);
                    final double dist = Nuker.mc.field_71439_g.func_70092_e((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p());
                    if (dist <= maxDist && blocks.contains(Nuker.mc.field_71441_e.func_180495_p(pos).func_177230_c()) && this.canBreak(pos)) {
                        maxDist = dist;
                        ret = pos;
                    }
                }
            }
        }
        return ret;
    }
    
    private BlockPos getClosestBlockAll() {
        float maxDist = this.distance.getValue();
        BlockPos ret = null;
        for (float x = maxDist; x >= -maxDist; --x) {
            for (float y = maxDist; y >= -maxDist; --y) {
                for (float z = maxDist; z >= -maxDist; --z) {
                    final BlockPos pos = new BlockPos(Nuker.mc.field_71439_g.field_70165_t + x, Nuker.mc.field_71439_g.field_70163_u + y, Nuker.mc.field_71439_g.field_70161_v + z);
                    final double dist = Nuker.mc.field_71439_g.func_70011_f((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p());
                    if (dist <= maxDist && Nuker.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150350_a && !(Nuker.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof BlockLiquid) && this.canBreak(pos) && pos.func_177956_o() >= Nuker.mc.field_71439_g.field_70163_u) {
                        maxDist = (float)dist;
                        ret = pos;
                    }
                }
            }
        }
        return ret;
    }
    
    private BlockPos getClosestBlockSelection() {
        float maxDist = this.distance.getValue();
        BlockPos ret = null;
        for (float x = maxDist; x >= -maxDist; --x) {
            for (float y = maxDist; y >= -maxDist; --y) {
                for (float z = maxDist; z >= -maxDist; --z) {
                    final BlockPos pos = new BlockPos(Nuker.mc.field_71439_g.field_70165_t + x, Nuker.mc.field_71439_g.field_70163_u + y, Nuker.mc.field_71439_g.field_70161_v + z);
                    final double dist = Nuker.mc.field_71439_g.func_70011_f((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p());
                    if (dist <= maxDist && Nuker.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150350_a && !(Nuker.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof BlockLiquid) && Nuker.mc.field_71441_e.func_180495_p(pos).func_177230_c() == this.selected && this.canBreak(pos) && pos.func_177956_o() >= Nuker.mc.field_71439_g.field_70163_u) {
                        maxDist = (float)dist;
                        ret = pos;
                    }
                }
            }
        }
        return ret;
    }
    
    public enum Mode
    {
        SELECTION, 
        ALL, 
        NUKE;
    }
}
