// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.misc;

import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketChatMessage;
import me.earth.phobos.features.modules.client.ClickGui;
import me.earth.phobos.features.modules.client.ServerModule;
import me.earth.phobos.features.command.Command;
import me.earth.phobos.Phobos;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.earth.phobos.features.gui.PhobosGui;
import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Mouse;
import me.earth.phobos.features.setting.Bind;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class MCF extends Module
{
    private final Setting<Boolean> middleClick;
    private final Setting<Boolean> keyboard;
    private final Setting<Boolean> server;
    private final Setting<Bind> key;
    private boolean clicked;
    
    public MCF() {
        super("MCF", "Middleclick Friends.", Category.MISC, true, false, false);
        this.middleClick = (Setting<Boolean>)this.register(new Setting("MiddleClick", (T)true));
        this.keyboard = (Setting<Boolean>)this.register(new Setting("Keyboard", (T)false));
        this.server = (Setting<Boolean>)this.register(new Setting("Server", (T)true));
        this.key = (Setting<Bind>)this.register(new Setting("KeyBind", (T)new Bind(-1), v -> this.keyboard.getValue()));
        this.clicked = false;
    }
    
    @Override
    public void onUpdate() {
        if (Mouse.isButtonDown(2)) {
            if (!this.clicked && this.middleClick.getValue() && MCF.mc.field_71462_r == null) {
                this.onClick();
            }
            this.clicked = true;
        }
        else {
            this.clicked = false;
        }
    }
    
    @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
    public void onKeyInput(final InputEvent.KeyInputEvent event) {
        if (this.keyboard.getValue() && Keyboard.getEventKeyState() && !(MCF.mc.field_71462_r instanceof PhobosGui) && this.key.getValue().getKey() == Keyboard.getEventKey()) {
            this.onClick();
        }
    }
    
    private void onClick() {
        final RayTraceResult result = MCF.mc.field_71476_x;
        if (result != null && result.field_72313_a == RayTraceResult.Type.ENTITY) {
            final Entity entity = result.field_72308_g;
            if (entity instanceof EntityPlayer) {
                if (Phobos.friendManager.isFriend(entity.func_70005_c_())) {
                    Phobos.friendManager.removeFriend(entity.func_70005_c_());
                    Command.sendMessage("§c" + entity.func_70005_c_() + "§r" + " unfriended.");
                    if (this.server.getValue() && ServerModule.getInstance().isConnected()) {
                        MCF.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Serverprefix" + ClickGui.getInstance().prefix.getValue()));
                        MCF.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Server" + ClickGui.getInstance().prefix.getValue() + "friend del " + entity.func_70005_c_()));
                    }
                }
                else {
                    Phobos.friendManager.addFriend(entity.func_70005_c_());
                    Command.sendMessage("§b" + entity.func_70005_c_() + "§r" + " friended.");
                    if (this.server.getValue() && ServerModule.getInstance().isConnected()) {
                        MCF.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Serverprefix" + ClickGui.getInstance().prefix.getValue()));
                        MCF.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Server" + ClickGui.getInstance().prefix.getValue() + "friend add " + entity.func_70005_c_()));
                    }
                }
            }
        }
        this.clicked = true;
    }
}
