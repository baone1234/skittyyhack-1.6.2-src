// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.misc;

import net.minecraft.network.play.client.CPacketVehicleMove;
import net.minecraft.network.play.client.CPacketInput;
import java.util.Objects;
import me.earth.phobos.Phobos;
import me.earth.phobos.event.events.UpdateWalkingPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.client.CPacketPlayer;
import me.earth.phobos.event.events.PacketEvent;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import me.earth.phobos.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import me.earth.phobos.features.modules.Module;

public class Godmode extends Module
{
    public Minecraft mc;
    public Entity entity;
    private final Setting<Boolean> remount;
    
    public Godmode() {
        super("Godmode", "Hi there :D", Category.MISC, true, false, false);
        this.mc = Minecraft.func_71410_x();
        this.remount = (Setting<Boolean>)this.register(new Setting("Remount", (T)false));
    }
    
    @Override
    public void onEnable() {
        super.onEnable();
        if (this.mc.field_71441_e != null && this.mc.field_71439_g.func_184187_bx() != null) {
            this.entity = this.mc.field_71439_g.func_184187_bx();
            this.mc.field_71438_f.func_72712_a();
            this.hideEntity();
            this.mc.field_71439_g.func_70107_b((double)Minecraft.func_71410_x().field_71439_g.func_180425_c().func_177958_n(), (double)(Minecraft.func_71410_x().field_71439_g.func_180425_c().func_177956_o() - 1), (double)Minecraft.func_71410_x().field_71439_g.func_180425_c().func_177952_p());
        }
        if (this.mc.field_71441_e != null && this.remount.getValue()) {
            this.remount.setValue(false);
        }
    }
    
    @Override
    public void onDisable() {
        super.onDisable();
        if (this.remount.getValue()) {
            this.remount.setValue(false);
        }
        this.mc.field_71439_g.func_184210_p();
        this.mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)this.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
        this.mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)this.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayer.Position || event.getPacket() instanceof CPacketPlayer.PositionRotation) {
            event.setCanceled(true);
        }
    }
    
    private void hideEntity() {
        if (this.mc.field_71439_g.func_184187_bx() != null) {
            this.mc.field_71439_g.func_184210_p();
            this.mc.field_71441_e.func_72900_e(this.entity);
        }
    }
    
    private void showEntity(final Entity entity2) {
        entity2.field_70128_L = false;
        this.mc.field_71441_e.field_72996_f.add(entity2);
        this.mc.field_71439_g.func_184205_a(entity2, true);
    }
    
    @SubscribeEvent
    public void onPlayerWalkingUpdate(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 0) {
            if (this.remount.getValue() && Objects.requireNonNull((Godmode)Phobos.moduleManager.getModuleByClass((Class<T>)Godmode.class)).isEnabled()) {
                this.showEntity(this.entity);
            }
            this.entity.func_70080_a(Minecraft.func_71410_x().field_71439_g.field_70165_t, Minecraft.func_71410_x().field_71439_g.field_70163_u, Minecraft.func_71410_x().field_71439_g.field_70161_v, Minecraft.func_71410_x().field_71439_g.field_70177_z, Minecraft.func_71410_x().field_71439_g.field_70125_A);
            this.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(this.mc.field_71439_g.field_70177_z, this.mc.field_71439_g.field_70125_A, true));
            this.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketInput(this.mc.field_71439_g.field_71158_b.field_192832_b, this.mc.field_71439_g.field_71158_b.field_78902_a, false, false));
            this.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketVehicleMove(this.entity));
        }
    }
}
