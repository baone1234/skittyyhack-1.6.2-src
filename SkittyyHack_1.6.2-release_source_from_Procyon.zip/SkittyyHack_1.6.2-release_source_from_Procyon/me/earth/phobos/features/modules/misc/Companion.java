// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.misc;

import me.earth.phobos.event.events.DeathEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.earth.phobos.event.events.TotemPopEvent;
import me.earth.phobos.features.setting.Setting;
import com.mojang.text2speech.Narrator;
import me.earth.phobos.features.modules.Module;

public class Companion extends Module
{
    private Narrator narrator;
    public Setting<String> totemPopMessage;
    public Setting<String> deathMessages;
    
    public Companion() {
        super("Companion", "The best module", Category.MISC, true, false, false);
        this.narrator = Narrator.getNarrator();
        this.totemPopMessage = (Setting<String>)this.register(new Setting("PopMessage", (T)"<player> watch out you're popping!"));
        this.deathMessages = (Setting<String>)this.register(new Setting("DeathMessage", (T)"<player> you retard you just fucking died!"));
    }
    
    @Override
    public void onEnable() {
        this.narrator.say("Hello and welcome to SkittyyHack 1.6.2");
    }
    
    @Override
    public void onDisable() {
        this.narrator.clear();
    }
    
    @SubscribeEvent
    public void onTotemPop(final TotemPopEvent event) {
        if (event.getEntity() == Companion.mc.field_71439_g) {
            this.narrator.say(this.totemPopMessage.getValue().replaceAll("<player>", Companion.mc.field_71439_g.func_70005_c_()));
        }
    }
    
    @SubscribeEvent
    public void onDeath(final DeathEvent event) {
        if (event.player == Companion.mc.field_71439_g) {
            this.narrator.say(this.deathMessages.getValue().replaceAll("<player>", Companion.mc.field_71439_g.func_70005_c_()));
        }
    }
}
