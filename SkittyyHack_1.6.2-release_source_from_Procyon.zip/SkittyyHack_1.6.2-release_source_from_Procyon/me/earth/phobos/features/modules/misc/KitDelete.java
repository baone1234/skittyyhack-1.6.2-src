// 
// Decompiled by Procyon v0.5.36
// 

package me.earth.phobos.features.modules.misc;

import net.minecraft.inventory.Slot;
import me.earth.phobos.util.TextUtil;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.gui.inventory.GuiContainer;
import me.earth.phobos.features.setting.Bind;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.features.modules.Module;

public class KitDelete extends Module
{
    private Setting<Bind> deleteKey;
    private boolean keyDown;
    
    public KitDelete() {
        super("KitDelete", "Automates /deleteukit", Category.MISC, false, false, false);
        this.deleteKey = (Setting<Bind>)this.register(new Setting("Key", (T)new Bind(-1)));
    }
    
    @Override
    public void onTick() {
        if (this.deleteKey.getValue().getKey() != -1) {
            if (KitDelete.mc.field_71462_r instanceof GuiContainer && Keyboard.isKeyDown(this.deleteKey.getValue().getKey())) {
                final Slot slot = ((GuiContainer)KitDelete.mc.field_71462_r).getSlotUnderMouse();
                if (slot != null && !this.keyDown) {
                    KitDelete.mc.field_71439_g.func_71165_d("/deleteukit " + TextUtil.stripColor(slot.func_75211_c().func_82833_r()));
                    this.keyDown = true;
                }
            }
            else if (this.keyDown) {
                this.keyDown = false;
            }
        }
    }
}
