// 
// Decompiled by Procyon v0.5.36
// 

package org.spongepowered.tools.obfuscation.interfaces;

public interface IOptionProvider
{
    String getOption(final String p0);
}
